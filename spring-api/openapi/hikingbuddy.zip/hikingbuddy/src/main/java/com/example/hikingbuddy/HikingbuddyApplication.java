package com.example.hikingbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HikingbuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HikingbuddyApplication.class, args);
	}

}
